//*******************************************************************
//        FILE:         header_start.cpp
// DESCRIPTION:         Receipt header
//*******************************************************************
#include "cyreceiptrcc.h"
using std::string;
