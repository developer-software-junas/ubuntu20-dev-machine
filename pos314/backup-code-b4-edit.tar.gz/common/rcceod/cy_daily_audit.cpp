/********************************************************************
          FILE:          cy_daily_audit.cpp
   DESCRIPTION:          Import audit information
 ********************************************************************/
//////////////////////////////////////////
//  Main header
#include "cypostrx.h"
//////////////////////////////////////////
//  Dereference the STD namespace
using std::endl;
using std::string;
using std::vector;
using std::stringstream;
/*******************************************************************
      FUNCTION:         cy_daily_audit
   DESCRIPTION:         Save the sales audit details
 *******************************************************************/
bool                    cypostrx::cy_daily_audit (CYDbSql* db)
{
    //TODO:
    (void)db;
    return true;
}
/*******************************************************************
      FUNCTION:         cy_daily_audit
   DESCRIPTION:         Save the sales audit details
 *******************************************************************/
bool                    cypostrx::cy_daily_audit_info (CYDbSql* db)
{
    //TODO:
    (void)db;
    return true;
}
/*******************************************************************
      FUNCTION:         cy_daily_audit
   DESCRIPTION:         Save the sales audit details
 *******************************************************************/
bool                    cypostrx::cy_daily_audit_display (CYDbSql* db)
{
    //TODO:
    (void)db;
    return true;
}
